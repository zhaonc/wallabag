# Change Log

## 1.4.1 - 2022-01-14

- Support Symfony 6

## 1.4.0 - 2020-11-30

### Added

- Support PHP 8

### Removed

- Dropped support for PHP < 7.3

## 1.3.0 - 2019-12-27

### Added

- Support for Symfony 5
- Support PHP 7.3

### Removed

- PHP 5 and PHP 7.0 support
- Symfony 2 support (disfunctional because php-http/client-commons no longer supports Symfony 2 anyways)

## 1.2.0 - 2019-01-30

### Added

- Support for php-http/client-common 2.0

## 1.1.0 - 2017-11-29

### Added

- Support for Symfony 4
- Show full URL in the event name

## 1.0.1 - 2016-05-19

### Added

- Support for Symfony 3
- Tests for various Symfony versions

### Removed

- Symfony 2.3 support


## 1.0.0 - 2016-05-05

- Initial release
