<?php

declare(strict_types=1);

namespace Http\HttplugBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * @author David Buchmann <mail@davidbu.ch>
 * @author Tobias Nyholm <tobias.nyholm@gmail.com>
 */
class HttplugBundle extends Bundle
{
}
